

const Footer=()=>{
    return(
        <>
        <hr/>
        <footer >
        <p>&copy; 2024 Designed By Sudhir Kumar</p>
        </footer>
        </>
    )
}

export default Footer;