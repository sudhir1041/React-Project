

const Skill=()=>{
    return(
        <>
        <section className="skill-section">
            <div className="skill">
                <h1>Skills</h1>
                <div className="skill-content">
                    <ul>
                        <li><h4>Python</h4></li>
                        <li><h4>Djnago</h4></li>
                        <li><h4>HTML & CSS</h4></li>
                        <li><h4>React</h4></li>
                    </ul>
                </div>
            </div>
        </section>
        </>
    )
}

export default Skill;