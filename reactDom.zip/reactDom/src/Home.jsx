



const Home=()=>{
    return(
        <>
        <h1>This is Home Page</h1>
        </>
    )
}

export default Home;