

const Home=()=>{
    return(

        <>
        <h1>Welcome To Cybrom </h1>
        </>
    )
}
export default Home;